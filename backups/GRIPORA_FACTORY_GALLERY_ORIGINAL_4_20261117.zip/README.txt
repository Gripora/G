GRIPORA factory gallery original four-image backup, 2026-11-17.
To restore, use index.html and the four factory WebP files from this archive.
GitHub rollback: backup-factory-gallery-4-before-add8-20261117.
